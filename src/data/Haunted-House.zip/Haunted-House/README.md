
# Haunted House - Console App

Hello, user! I'm very excited to share my very first text-based adventure console app. 
Although still a little buggy, this was my first project focusing on objects in C#. I hope you enjoy it and I welcome any feedback you might offer. Although I believe there are improvements to be made on this program, I'm moving my attention to a new dungeon_crawler. More details to come!
